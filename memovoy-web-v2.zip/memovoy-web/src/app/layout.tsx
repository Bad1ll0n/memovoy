// src/app/layout.tsx
import type { Metadata, Viewport } from 'next'
import { Inter, Playfair_Display } from 'next/font/google'
import './globals.css'
import { Providers } from '@/components/layout/Providers'

// Display: Playfair Display — evoca diários de viagem, elegância editorial
const displayFont = Playfair_Display({
  subsets:  ['latin'],
  variable: '--font-display',
  display:  'swap',
})

// Body: Inter — legibilidade máxima em ecrãs pequenos e grandes
const bodyFont = Inter({
  subsets:  ['latin'],
  variable: '--font-body',
  display:  'swap',
})

export const metadata: Metadata = {
  title:       { default: 'MemoVoy', template: '%s · MemoVoy' },
  description: 'A tua rede social de viagens. Cria roteiros, partilha aventuras, inspira-te.',
  keywords:    ['viagens', 'roteiros', 'travel', 'itinerary', 'social'],
  openGraph: {
    type:      'website',
    siteName:  'MemoVoy',
    locale:    'pt_PT',
  },
  twitter: { card: 'summary_large_image' },
  robots: {
    index:  true,
    follow: true,
  },
}

export const viewport: Viewport = {
  width:          'device-width',
  initialScale:   1,
  themeColor:     '#185FA5',
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html
      lang="pt"
      className={`${displayFont.variable} ${bodyFont.variable}`}
      suppressHydrationWarning
    >
      <body className="bg-surface-subtle font-body text-ink antialiased">
        <Providers>{children}</Providers>
      </body>
    </html>
  )
}
