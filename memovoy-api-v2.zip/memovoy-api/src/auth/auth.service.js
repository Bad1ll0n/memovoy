// src/auth/auth.service.js
// Lógica de negócio de autenticação.
// Sem dependências de Fastify — testável isoladamente.

import crypto from 'node:crypto'
import argon2 from 'argon2'
import { config } from '../config/index.js'
import {
  ConflictError,
  UnauthorizedError,
  NotFoundError,
  ValidationError,
} from '../shared/errors/index.js'

// -------------------------------------------------------
// Utilitários de encriptação do email
// -------------------------------------------------------

// Encriptar email com AES-256-GCM
export function encryptEmail(email) {
  const key = Buffer.from(config.crypto.emailKey, 'base64')
  const iv = crypto.randomBytes(12) // 96 bits para GCM
  const cipher = crypto.createCipheriv('aes-256-gcm', key, iv)
  const encrypted = Buffer.concat([
    cipher.update(email.toLowerCase(), 'utf8'),
    cipher.final(),
  ])
  const tag = cipher.getAuthTag()
  // Formato: iv(12) + tag(16) + encrypted — tudo em base64
  return Buffer.concat([iv, tag, encrypted]).toString('base64')
}

// Hash do email para lookup (SHA-256 normalizado)
export function hashEmail(email) {
  return crypto
    .createHash('sha256')
    .update(email.toLowerCase().trim())
    .digest('hex')
}

// -------------------------------------------------------
// AuthService — métodos principais
// -------------------------------------------------------
export class AuthService {
  constructor(db, jwtPlugin) {
    this.db = db
    this.jwt = jwtPlugin
  }

  // -------------------------------------------------------
  // Registar novo utilizador
  // -------------------------------------------------------
  async register({ email, password, username, countryCode, language }) {
    const emailHash = hashEmail(email)
    const emailEncrypted = encryptEmail(email)

    // Verificar email único (sem revelar se existe — timing safe)
    const { sql, transaction } = this.db
    const existing = await sql`
      SELECT id FROM users
      WHERE email_hash = ${emailHash}
        AND deleted_at IS NULL
      LIMIT 1
    `
    if (existing.length > 0) {
      throw new ConflictError('Este email já está registado')
    }

    // Verificar username único
    const existingUsername = await sql`
      SELECT id FROM users
      WHERE username = ${username.toLowerCase()}
        AND deleted_at IS NULL
      LIMIT 1
    `
    if (existingUsername.length > 0) {
      throw new ConflictError('Este username já está em uso')
    }

    // Hash da password com argon2id (mais seguro que bcrypt)
    const passwordHash = await argon2.hash(password, {
      type: argon2.argon2id,
      memoryCost: 65536, // 64MB
      timeCost: 3,
      parallelism: 4,
    })

    // Determinar db_region pelo país
    const dbRegion = ['PT', 'ES', 'FR', 'DE', 'IT', 'NL', 'BE', 'PL', 'SE', 'NO', 'DK', 'FI', 'AT', 'CH', 'IE', 'RO'].includes(countryCode?.toUpperCase())
      ? 'eu-central-1'
      : 'sa-east-1'

    // Criar utilizador + perfil + preferências numa transacção
    const user = await transaction(async (tx) => {
      const [newUser] = await tx`
        INSERT INTO users (
          email_encrypted, email_hash, username,
          password_hash, auth_provider, db_region,
          country_code, language, role,
          is_verified, gdpr_consent_at
        ) VALUES (
          ${emailEncrypted}, ${emailHash}, ${username.toLowerCase()},
          ${passwordHash}, 'email', ${dbRegion},
          ${countryCode?.toUpperCase() ?? null}, ${language ?? 'pt-PT'}, 'user',
          false, NOW()
        )
        RETURNING id, username, role, db_region, created_at
      `

      // Criar perfil público
      await tx`
        INSERT INTO user_profiles (user_id, display_name)
        VALUES (${newUser.id}, ${username})
      `

      // Criar preferências com defaults
      await tx`
        INSERT INTO user_preferences (user_id)
        VALUES (${newUser.id})
      `

      // Criar streak inicial
      await tx`
        INSERT INTO streaks (user_id)
        VALUES (${newUser.id})
      `

      return newUser
    })

    // Gerar tokens
    const tokens = this._generateTokens(user)

    // Guardar refresh token na BD
    await this._saveRefreshToken(user.id, tokens.refreshToken)

    return { user, ...tokens }
  }

  // -------------------------------------------------------
  // Login com email + password
  // -------------------------------------------------------
  async login({ email, password, deviceFingerprint, ipCountry }) {
    const { sql } = this.db
    const emailHash = hashEmail(email)

    // Buscar utilizador pelo hash do email
    const [user] = await sql`
      SELECT id, username, role, db_region, password_hash,
             is_verified, mfa_enabled, deleted_at
      FROM users
      WHERE email_hash = ${emailHash}
      LIMIT 1
    `

    // Utilizador não existe — mesmo erro que password errada (timing attack)
    if (!user || user.deleted_at) {
      // Hash dummy para manter timing constante
      await argon2.verify(
        '$argon2id$v=19$m=65536,t=3,p=4$dummydummydummy$dummydummydummydummydummydummydummydummy',
        password
      ).catch(() => {})
      throw new UnauthorizedError('Credenciais inválidas')
    }

    // Verificar password
    const valid = await argon2.verify(user.password_hash, password)
    if (!valid) {
      throw new UnauthorizedError('Credenciais inválidas')
    }

    // Detectar sessão suspeita (país diferente do último login)
    const isSuspicious = await this._checkSuspicious(user.id, ipCountry)

    // Registar sessão
    const [session] = await sql`
      INSERT INTO user_sessions (
        user_id, device_fingerprint, ip_country,
        is_suspicious, expires_at
      ) VALUES (
        ${user.id},
        ${deviceFingerprint ?? null},
        ${ipCountry ?? null},
        ${isSuspicious},
        NOW() + INTERVAL '30 days'
      )
      RETURNING id
    `

    // Gerar tokens
    const tokens = this._generateTokens(user, session.id)

    // Se sessão suspeita — notificar (não bloquear)
    if (isSuspicious) {
      await sql`
        INSERT INTO notifications (user_id, type, title, channel, status)
        VALUES (
          ${user.id},
          'session_suspicious',
          'Novo login detectado de localização diferente',
          'push',
          'pending'
        )
      `
    }

    return {
      user: {
        id: user.id,
        username: user.username,
        role: user.role,
        isVerified: user.is_verified,
        isSuspicious,
      },
      ...tokens,
    }
  }

  // -------------------------------------------------------
  // Renovar Access Token com Refresh Token
  // -------------------------------------------------------
  async refresh(refreshToken) {
    let payload
    try {
      payload = this.jwt.verify(refreshToken, {
        key: config.jwt.refreshSecret,
      })
    } catch {
      throw new UnauthorizedError('Refresh token inválido ou expirado')
    }

    const { sql } = this.db

    // Verificar que a sessão ainda está activa na BD
    const [session] = await sql`
      SELECT us.id, us.user_id, u.role, u.db_region, u.deleted_at
      FROM user_sessions us
      JOIN users u ON u.id = us.user_id
      WHERE us.id = ${payload.sessionId}
        AND us.revoked_at IS NULL
        AND us.expires_at > NOW()
      LIMIT 1
    `

    if (!session || session.deleted_at) {
      throw new UnauthorizedError('Sessão inválida ou expirada')
    }

    // Gerar novo access token (refresh token mantém-se)
    const accessToken = this.jwt.sign(
      {
        sub: session.user_id,
        role: session.role,
        dbRegion: session.db_region,
        sessionId: session.id,
      },
      {
        key: config.jwt.accessSecret,
        expiresIn: config.jwt.accessTtl,
      }
    )

    return { accessToken }
  }

  // -------------------------------------------------------
  // Logout — revogar sessão
  // -------------------------------------------------------
  async logout(sessionId, userId) {
    const { sql } = this.db
    await sql`
      UPDATE user_sessions
      SET revoked_at = NOW()
      WHERE id = ${sessionId}
        AND user_id = ${userId}
        AND revoked_at IS NULL
    `
  }

  // -------------------------------------------------------
  // Revogar todas as outras sessões (ecrã de segurança)
  // -------------------------------------------------------
  async revokeOtherSessions(currentSessionId, userId) {
    const { sql } = this.db
    const result = await sql`
      UPDATE user_sessions
      SET revoked_at = NOW()
      WHERE user_id = ${userId}
        AND id != ${currentSessionId}
        AND revoked_at IS NULL
      RETURNING id
    `
    return result.length
  }

  // -------------------------------------------------------
  // Métodos privados
  // -------------------------------------------------------

  _generateTokens(user, sessionId = null) {
    const payload = {
      sub: user.id,
      role: user.role,
      dbRegion: user.db_region,
      ...(sessionId && { sessionId }),
    }

    const accessToken = this.jwt.sign(payload, {
      key: config.jwt.accessSecret,
      expiresIn: config.jwt.accessTtl,
    })

    const refreshToken = this.jwt.sign(
      { ...payload, type: 'refresh' },
      {
        key: config.jwt.refreshSecret,
        expiresIn: config.jwt.refreshTtl,
      }
    )

    return { accessToken, refreshToken }
  }

  async _saveRefreshToken(userId, refreshToken) {
    // O refresh token é guardado como sessão na BD
    // O jti do token é o ID da sessão
    const payload = this.jwt.decode(refreshToken)
    const { sql } = this.db
    await sql`
      INSERT INTO user_sessions (
        user_id, expires_at
      ) VALUES (
        ${userId},
        to_timestamp(${payload.exp})
      )
    `
  }

  async _checkSuspicious(userId, ipCountry) {
    if (!ipCountry) return false
    const { sql } = this.db
    const [last] = await sql`
      SELECT ip_country FROM user_sessions
      WHERE user_id = ${userId}
        AND revoked_at IS NULL
        AND ip_country IS NOT NULL
      ORDER BY created_at DESC
      LIMIT 1
    `
    if (!last) return false
    return last.ip_country !== ipCountry
  }
}
