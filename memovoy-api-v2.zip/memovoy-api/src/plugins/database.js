// src/plugins/database.js
// Plugin Fastify que expõe o pool PostgreSQL como fastify.db
// e utilitários para transações com RLS automático.

import fp from 'fastify-plugin'
import postgres from 'postgres'
import { config } from '../config/index.js'

async function databasePlugin(fastify) {
  const sql = postgres(config.db.url, {
    min: config.db.poolMin,
    max: config.db.poolMax,
    idle_timeout: 30,
    connect_timeout: 10,
    // Todas as queries devem passar pelo helper withUser() para RLS
    // Esta opção activa a extensão de tipos PostgreSQL (UUID, JSONB, etc.)
    types: {
      // UUID — receber como string
      bigint: postgres.BigInt,
    },
    onnotice: (notice) => {
      fastify.log.debug({ notice }, 'PostgreSQL notice')
    },
  })

  // Testar ligação ao arranque
  try {
    await sql`SELECT 1`
    fastify.log.info('✓ PostgreSQL ligado')
  } catch (err) {
    fastify.log.error({ err }, '✗ Falha na ligação ao PostgreSQL')
    throw err
  }

  // -------------------------------------------------------
  // Helper: executar queries com RLS configurado para o user
  // Todas as routes autenticadas DEVEM usar este helper.
  //
  // Uso:
  //   const rows = await fastify.db.withUser(userId, role, async (sql) => {
  //     return sql`SELECT * FROM user_profiles WHERE user_id = ${userId}`
  //   })
  // -------------------------------------------------------
  const withUser = async (userId, role, fn) => {
    return sql.begin(async (tx) => {
      // Definir variáveis de sessão para RLS — locais à transacção
      await tx`SELECT set_config('app.current_user_id', ${userId}, true)`
      await tx`SELECT set_config('app.current_user_role', ${role}, true)`
      return fn(tx)
    })
  }

  // -------------------------------------------------------
  // Helper: transacção sem RLS (para operações de sistema/migrations)
  // Só usar em contexts sem utilizador autenticado.
  // -------------------------------------------------------
  const transaction = async (fn) => {
    return sql.begin(fn)
  }

  // Expor no fastify
  fastify.decorate('db', { sql, withUser, transaction })

  // Fechar pool quando o servidor terminar
  fastify.addHook('onClose', async () => {
    await sql.end()
    fastify.log.info('PostgreSQL pool fechado')
  })
}

// fastify-plugin garante que o decorator é partilhado por todos os plugins
export default fp(databasePlugin, {
  name: 'database',
  fastify: '4.x',
})
